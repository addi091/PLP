package com.cg.entity;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Registration {

	@FindBy(id="firstName")
	private WebElement firstName;
	
	@FindBy(id="lastName")
	private WebElement lastName;
	
	@FindBy(id="address")
	private WebElement address;
	
	@FindBy(id="email")
	private WebElement email;
	
	@FindBy(id="password")
	private WebElement password;
		
	@FindBy(id="repeatPassword")
	private WebElement repeatPassword;
	
	@FindBy(name="gender")
	private WebElement gender;
	
	@FindBy(name="dateOfBirth")
	private WebElement dateOfBirth;

	@FindBy(id="reister")
	private WebElement reister;
	
	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPassword() {
		return this.password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public String getAddress() {
		return this.address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getRepeatPassword() {
		return this.repeatPassword.getAttribute("value");
	}

	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword.sendKeys(repeatPassword);
	}
	

	public String getGender() {
		return this.gender.getAttribute("value");
	}

	public void setGender(String gender) {
		this.gender.sendKeys(gender); 
	}

	public String getDateOfBirth() {
		return this.dateOfBirth.getAttribute("value");
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth); 
	}

	public void selectGender(int i) {
		Select select = new Select(gender);
		select.selectByIndex(i);
	}
	
	public void selectDateOfBirth(int i) {
		Select select = new Select(dateOfBirth);
		select.selectByIndex(i);
	}

	public void clickReister() {
		reister.click();
	}
}
