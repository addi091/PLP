package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.entity.Registration;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {

	private WebDriver driver;

	private Registration registration;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");

	}

	@Given("^User is on Registration Page$")
	public void user_is_on_Registration_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/adsinha/Spring/BDD_Practice/html/PersonalDetails.html");
		Thread.sleep(1000);
		registration = new Registration();
		PageFactory.initElements(driver, registration);
	}

	@When("^user enters invalid firstName$")
	public void user_enters_invalid_firstName() throws Throwable {
		registration.setFirstName("");
	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		registration.clickReister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid lastName$")
	public void user_enters_invalid_lastName() throws Throwable {
		registration.setFirstName("abcd");
		registration.setLastName("");
	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		registration.clickReister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Throwable {
		registration.setFirstName("abcd");
		registration.setLastName("defg");
		registration.setAddress("");
	}

	@Then("^display 'Please fill the Address'$")
	public void display_Please_fill_the_Address() throws Throwable {
		registration.clickReister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		registration.setFirstName("abcd");
		registration.setLastName("defg");
		registration.setAddress("airoli");
		registration.setPassword("");
	}

	@Then("^display 'Please enter valid Password'$")
	public void display_Please_enter_valid_Password() throws Throwable {
		registration.clickReister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid repeat password$")
	public void user_enters_invalid_repeat_password() throws Throwable {
		registration.setFirstName("abcd");
		registration.setLastName("defg");
		registration.setAddress("airoli");
		registration.setPassword("Abcd@1234");
		registration.setRepeatPassword("");
	}

	@Then("^display 'Please enter the Repeat Password'$")
	public void display_Please_enter_the_Repeat_Password() throws Throwable {
		registration.clickReister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid gender$")
	public void user_enters_invalid_gender() throws Throwable {
		registration.setFirstName("abcd");
		registration.setLastName("defg");
		registration.setAddress("airoli");
		registration.setPassword("Abcd@1234");
		registration.setRepeatPassword("Abcd@1234");
		registration.selectGender(0);
	}

	@Then("^display 'Please Select the Gender'$")
	public void display_Please_Select_the_Gender() throws Throwable {
		registration.clickReister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid date of birth$")
	public void user_enters_invalid_date_of_birth() throws Throwable {
		registration.setFirstName("abcd");
		registration.setLastName("defg");
		registration.setAddress("airoli");
		registration.setPassword("Abcd@1234");
		registration.setRepeatPassword("Abcd@1234");
		registration.selectGender(1);
		registration.selectDateOfBirth(0);
	}

	@Then("^display 'Please Select the Date of Birth'$")
	public void display_Please_Select_the_Date_of_Birth() throws Throwable {
		registration.clickReister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^User submits form$")
	public void user_submits_form() throws Throwable {
		registration.setFirstName("abcd");
		registration.setLastName("defg");
		registration.setAddress("airoli");
		registration.setPassword("Abcd@1234");
		registration.setRepeatPassword("Abcd@1234");
		registration.selectGender(1);
		registration.selectDateOfBirth(1);
	}

	@Then("^show successful register alert$")
	public void show_successful_register_alert() throws Throwable {
		registration.clickReister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}
}
