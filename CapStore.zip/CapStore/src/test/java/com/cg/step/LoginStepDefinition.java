package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.entity.Login;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {

	private WebDriver driver;

	private Login login;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");

	}

	@Given("^User is on Login Page$")
	public void user_is_on_Login_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/adsinha/Spring/BDD_Practice/html/PersonalDetails.html");
		Thread.sleep(1000);
		login = new Login();
		PageFactory.initElements(driver, login);
	}

	@When("^user enters url$")
	public void user_enters_url() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		login.setEmail("");
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		login.setEmail("ak@gl.co");
		login.setPassword("");
	}

	@Then("^display 'Please fill the Password'$")
	public void display_Please_fill_the_Password() throws Throwable {
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^User submits form$")
	public void user_submits_form() throws Throwable {
		login.setEmail("ak@gl.co");
		login.setPassword("Abcd@1234");
	}

	@Then("^show successful Login alert$")
	public void show_successful_Login_alert() throws Throwable {
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}
}
